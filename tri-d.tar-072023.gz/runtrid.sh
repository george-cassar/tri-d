#!/bin/bash
# This script is provided free of charge by IBM Corporation as a
# convenience to its customers.  This script is provided "AS-IS" with
# no warranty whatsoever.  The customer accepts all risk in connection
# with the use of this script, and IBM Corporation shall have no
# liability whatsoever.
#**********************************************************************
# Last Updated 
tridv=7.0
#5/4/2021 Begining of Version 7
#
#**********************************************************************
ODIR=output_$(date +"%Y-%m-%d-%H-%M-%S")

echo

# Check that NZ is Online
if [ `nzstate | grep Online | wc -l` -eq 0 ]
then
	# NZ is not Online, exit
	echo "Sorry, Netezza is not Online.  Please run nzstart and then rerun the collection script."
	exit
fi

mkdir $ODIR
cp -rp scripts/ $ODIR/


if [ "$#" -eq 1 ] 
then
# Use the query history view
# Specify the database for the view nz_query_history_view
# You can use "nz_find_object nz_query_history_view" to find the database
	use_db=0
	histdb=$1
elif [ "$#" -eq 2 ] 
then
# Manual override for specifying the history database and version
# This is used if there is a misconfiguration, or to query a restored database
	use_db=1
	histdb=$1
	ver=$2
	echo "Using query history database ${histdb}, version ${ver}"
else
	histdb=`nzsql -tc "select config_dbname, config_version from _v_hist_config where config_current = true;"|cut -d'|' -f1|tr -d '[:space:]'`
	ver=`nzsql -tc "select config_dbname, config_version from _v_hist_config where config_current = true;"|cut -d'|' -f2|tr -d '[:space:]'`
	
	# Check if history configuration exists
	if [ -z "${histdb}" ]
	then
		# Configuration not enabled
		echo "History configuration/database is not enabled."
		echo "Checking for nz_query_history_view..."
		echo
		/nz/support/bin/nz_find_object nz_query_history_view | tee $ODIR/nz_find_object.txt
		echo
		echo "Please re-run this script using the database and table information indicated above and using this syntax:"
		echo "./runtrid.sh <history database>"
		echo "where <history database> is the name of your query history database that contains nz_query_history_view (typically HISTDB)"
		echo
		echo "If there is no output in the table above, or multiple options listed, please contact your IBM representative and provide the above output for assistance."
		echo
		exit
	fi
	use_db=1
	echo "Using query history database ${histdb}, version ${ver}"
	
	nzsql -c "show history configuration all" > $ODIR/histconf.txt
fi

# Check if history db tables exist

if [[ use_db -eq 1 ]]
then
	# Update scripts to use the correct query history database version
	for file in int-query-day.sql  int-query-dow.sql  int-query-yr.sql  int-query-by-user.sql  int-query-by-database.sql int-query-by-user-database.sql; do
		sed -i "s/QUERYPROLOG/hist_query_prolog_${ver}/g" $ODIR/scripts/${file}
		sed -i "s/PLANPROLOG/hist_plan_prolog_${ver}/g" $ODIR/scripts/${file}
		sed -i "s/PLANEPILOG/hist_plan_epilog_${ver}/g" $ODIR/scripts/${file}
	done
	
	# Check that all necessary tables exist
	if [[ `nzsql -d ${histdb} -c "select tablename from _v_table where database <> 'SYSTEM'" | grep -i "\\\$hist_query_prolog_${ver}\|\\\$hist_plan_prolog_${ver}\|\\\$hist_plan_epilog_${ver}"|wc -l` -eq 3 ]]
	then
		# History db tables exist
		
		echo "Collecting query history statistics using query history database..."
		nzsql -d $histdb -f $ODIR/scripts/int-query-day.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/int-query-day.csv
		nzsql -d $histdb -f $ODIR/scripts/int-query-dow.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/int-query-dow.csv
		nzsql -d $histdb -f $ODIR/scripts/int-query-yr.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/int-query-yr.csv
		nzsql -d $histdb -f $ODIR/scripts/int-query-by-user.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/int-query-by-user.csv
		nzsql -d $histdb -f $ODIR/scripts/int-query-by-user-database.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/int-query-by-user-database.csv
		nzsql -d $histdb -f $ODIR/scripts/int-query-by-database.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/int-query-by-database.csv
	else
		# Database exists but tables do not
		echo "Sorry, we could not find the required history tables. Please contact your IBM representative."
		exit
	fi
else
	# Use nz_query_history table 
	
	if [[ `nzsql -d ${histdb} -c "select viewname from _v_view where database <> 'SYSTEM'" | grep -i "nz_query_history_view"|wc -l` -eq 1 ]]
		then
		echo "Collecting query history statistics using query history view..."
		nzsql -d $histdb -f $ODIR/scripts/qh-query-day.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/qh-query-day.csv
		nzsql -d $histdb -f $ODIR/scripts/qh-query-dow.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/qh-query-dow.csv
		nzsql -d $histdb -f $ODIR/scripts/qh-query-yr.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/qh-query-yr.csv
		nzsql -d $histdb -f $ODIR/scripts/qh-query-by-user.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/qh-query-by-user.csv
		nzsql -d $histdb -f $ODIR/scripts/qh-query-by-database.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/qh-query-by-database.csv
		nzsql -d $histdb -f $ODIR/scripts/qh-query-by-user-database.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/qh-query-by-user-database.csv
	
else
		echo 
		echo "Could not find the query history table. "
		exit
	fi
fi

# Read Write collection
if [[ `nzsql -d $histdb -c "select tablename from _v_table where database <> 'SYSTEM' and tablename = 'NZ_QUERY_HISTORY'" | grep -i "nz_query_history"|wc -l` -eq 1 ]]
then
        nzsql -d $histdb -f $ODIR/scripts/qh-read-write.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/qh-read-write.csv 2>&1
else
        nzsql -d $histdb -f $ODIR/scripts/int-read-write.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/int-read-write.csv 2>&1
fi

# Run CPU stats collection
if [[ `nzsql -d $histdb -c "select tablename from _v_table where database <> 'SYSTEM'" | grep -i "nz_sysutil_history"|wc -l` -eq 1 ]]
then 
	nzsql -d $histdb -f $ODIR/scripts/util-cpu-hour.sql | sed -e '/-----/d' -e '/rows)/d' > $ODIR/util-cpu-hour.csv 2>&1
fi

echo "Collecting database stats..."
/nz/support/bin/nz_stats -verbose > $ODIR/nzstats.txt
############################################################
##
## Creating a csv file for Trident Tool use
##
############################################################
sed '16!d' $ODIR/nzstats.txt > $ODIR/nz_objects_stg.csv
sed '17!d' $ODIR/nzstats.txt >> $ODIR/nz_objects_stg.csv
sed '18!d' $ODIR/nzstats.txt >> $ODIR/nz_objects_stg.csv
sed '19!d' $ODIR/nzstats.txt >> $ODIR/nz_objects_stg.csv
sed '20!d' $ODIR/nzstats.txt >> $ODIR/nz_objects_stg.csv
sed 's/\(^.\{1,35\}\).*/\1/' $ODIR/nz_objects_stg.csv > $ODIR/nz_objects.csv
rm $ODIR/nz_objects_stg.csv
############################################################
/nz/support/bin/nz_db_size -summary -s -mb -gb -tb > $ODIR/nz_db_size.txt
#/nz/support/bin/nz_db_size -mb -gb -tb >> $ODIR/nz_db_size.txt
/nz/support/bin/nz_storage_stats >> $ODIR/nz_storage_stats.txt

echo "Collecting Health Output..."
/nz/support/bin/nz_health >> $ODIR/nz_health.txt

echo $tridv > $ODIR/runtrid_v.txt

echo "Collecting System Info..." 
nzsystem showregistry | grep -i systemlimit >> $ODIR/system_settings.txt
 
echo "Compressing data..."
if [ -e trid_output.zip ]
then
  rm trid_output.zip
fi
zip -rq trid_output.zip $ODIR/*
echo
echo "Collection complete. Please send the trid_output.zip file to your IBM representative."
echo

