select qh_tsubmit::date dt, extract(hour from qh_tsubmit) hr, qh_user, count(*) cnt,
avg(queued_seconds) qtime,
avg(elapsed_seconds) rtime
from nz_query_history_view where qh_tsubmit::date > current_date - 365 and (upper(qh_database) not like 'SYSTEM%' and upper(qh_database) not like 'DBA_INFO%' and upper(qh_database) not like 'HISTDB%') group by 1,2,3 order by 1,2,3;
