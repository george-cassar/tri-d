----SPU CPU Util by Hour 
select entry::date,
extract(hour from entry) hr, 
(avg(spu_cpu)::numeric(8,2) *100)::smallint avg_spucpu, 
(avg(spu_disk)::numeric(8,2) *100)::smallint avg_spudisk, 
(avg(max_spu_cpu)*100)::smallint avg_max_spucpu, 
(max(max_spu_cpu)*100)::smallint max_spu_cpu
from nz_sysutil_history 
where entry::date > (current_date - 365 - extract(day from current_date)) group by 1,2 order by 1,2;

