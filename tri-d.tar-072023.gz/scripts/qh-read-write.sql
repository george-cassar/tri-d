SELECT
    substr(qh_tstart,1,13) || ':00:00' as THE_DATE,
    --extract(hour from timestamp_to_localtime(qh_tstart)) hr,
    SUM(SPU_DATA_DISK_READ_SECS) AS "read",
    SUM(SPU_DATA_DISK_WRITE_SECS) AS "write",
    SUM(SPU_DATA_DISK_READ_SECS+SPU_DATA_DISK_WRITE_SECS) AS "total",
    case when "total" != 0 then ("read"/ "total")::numeric(18, 2) else 0 end AS "read %",
    case when "total" != 0 then ("write"/ "total")::numeric(18, 2) else 0 end AS "write %"
FROM nz_query_history
WHERE qh_tstart::date  > (current_date - 365 - extract(day from current_date))
GROUP BY THE_DATE
ORDER BY 1
;
